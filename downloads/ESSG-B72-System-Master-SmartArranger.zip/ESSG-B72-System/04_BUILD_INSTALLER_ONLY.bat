@echo off
title EXCEL Smart STG - Build Windows Installer
cd /d "%~dp0"

if not exist build-logs mkdir build-logs

echo ================================================
echo  EXCEL Smart STG - Build Windows Installer
echo ================================================
echo.
echo This builds the official installer EXE.
echo Output:
echo dist\EXCEL-Smart-STG-Setup-1.0.0-Build72.exe
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not added to PATH.
  echo Install Node.js LTS, close this window, then open this BAT again.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: npm is not installed or not added to PATH.
  echo Reinstall Node.js LTS and tick the option to add it to PATH.
  pause
  exit /b 1
)

if not exist package.json (
  echo ERROR: package.json not found.
  echo Make sure you extracted the ZIP first and are running this BAT inside the main EXCEL Smart STG folder.
  pause
  exit /b 1
)

echo Installing/checking dependencies...
call npm install --no-audit --no-fund > build-logs\npm-install.log 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: npm install failed.
  echo Open build-logs\npm-install.log to see the exact reason.
  pause
  exit /b 1
)

echo Building installer...
call npm run dist:installer > build-logs\installer-only.log 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: Installer build failed.
  echo Open build-logs\installer-only.log to see the exact reason.
  echo.
  echo Common fixes:
  echo - Close the app if it is currently open.
  echo - Move this folder to C:\EXCEL-Smart-STG
  echo - Make sure the ZIP was fully extracted.
  echo - Temporarily allow the build through antivirus/Windows Defender.
  echo.
  pause
  exit /b 1
)

echo.
echo Installer build finished.
echo Look inside the dist folder for:
echo EXCEL-Smart-STG-Setup-1.0.0-Build72.exe
echo.
dir dist
pause
