@echo off
call "%~dp005_BUILD_PORTABLE_ONLY.bat"
