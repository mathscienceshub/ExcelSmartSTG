@echo off
title EXCEL Smart STG - Build Portable Only
cd /d "%~dp0"

if not exist build-logs mkdir build-logs

if not exist node_modules (
  call 01_INSTALL_DEPENDENCIES.bat
)

call npm run dist:portable > build-logs\portable-only.log 2>&1

if errorlevel 1 (
  echo ERROR: Portable build failed. Check build-logs\portable-only.log
  pause
  exit /b 1
)

dir dist
pause
