@echo off
title EXCEL Smart STG - Test Desktop App
cd /d "%~dp0"

if not exist node_modules (
  echo Dependencies are missing. Running installer first...
  call 01_INSTALL_DEPENDENCIES.bat
)

echo ================================================
echo  EXCEL Smart STG - Test Desktop App
echo ================================================
echo.

call npm start

pause
