@echo off
title EXCEL Smart STG - Check Requirements
cd /d "%~dp0"

echo ================================================
echo  EXCEL Smart STG - Requirements Check
echo ================================================
echo.

echo Checking Node.js...
node -v
if errorlevel 1 (
  echo.
  echo ERROR: Node.js is not installed or not available in PATH.
  echo Install Node.js LTS, then restart your computer and try again.
  pause
  exit /b 1
)

echo.
echo Checking npm...
npm -v
if errorlevel 1 (
  echo.
  echo ERROR: npm is not available.
  echo Reinstall Node.js LTS and make sure npm is selected.
  pause
  exit /b 1
)

echo.
echo Requirements look okay.
echo Now run 01_INSTALL_DEPENDENCIES.bat
echo.
pause
