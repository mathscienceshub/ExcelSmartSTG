const fs = require("fs");
const readline = require("readline");
const path = require("path");

const SECRET = "MSH_EXCELLENCE_STG_OFFLINE_LICENCE_2026";
const COMPANY = "Maths n Sciences Hub (Pty) Ltd";
const REG_NO = "2026/337825/07";
const SUPPORT_PHONE = "+27 76 106 9888 / +27 78 204 3618";
const SUPPORT_EMAIL = "chrisabel3414@gmail.com";

function hash(input) {
  let h = 2166136261;
  const text = String(input || "");
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h += (h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24);
  }
  return ("00000000" + (h >>> 0).toString(16).toUpperCase()).slice(-8);
}

function canonical(licence) {
  return [
    licence.product || "EXCEL Smart STG",
    licence.productName || "EXCELlence Smart School Timetable Generator",
    licence.schoolName || licence.issuedTo || "",
    licence.issuedTo || licence.schoolName || "",
    licence.licenceType || "",
    licence.licenceKey || "",
    licence.validFrom || "",
    licence.validUntil || "",
    String(licence.allowedDevices || 1),
    licence.version || "1.0.0",
    String(licence.build || "62"),
    SECRET
  ].join("|");
}

function sign(licence) {
  licence.signature = hash(canonical(licence));
  return licence;
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function ask(question, fallback = "") {
  return new Promise(resolve => rl.question(`${question}${fallback ? ` [${fallback}]` : ""}: `, answer => resolve(answer.trim() || fallback)));
}

(async () => {
  console.log("EXCEL Smart STG Licence Creator - Build 62");
  console.log("Produced under Maths n Sciences Hub (Pty) Ltd");
  console.log("");

  const schoolName = await ask("School / client name");
  const licenceType = await ask("Licence type", "Annual");
  const validFrom = await ask("Valid from (YYYY-MM-DD)", new Date().toISOString().slice(0,10));
  const validUntil = await ask("Valid until (YYYY-MM-DD or LIFETIME)", "2027-12-31");
  const allowedDevices = Number(await ask("Allowed devices", "1"));
  const keySuffix = schoolName.toUpperCase().replace(/[^A-Z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0,24) || "CLIENT";
  const licenceKey = await ask("Licence key", `EXSTG-${keySuffix}-${new Date().getFullYear()}-001`);

  const licence = sign({
    product: "EXCEL Smart STG",
    productName: "EXCELlence Smart School Timetable Generator",
    schoolName,
    issuedTo: schoolName,
    licenceType,
    licenceKey,
    validFrom,
    validUntil,
    allowedDevices,
    version: "1.0.0",
    build: "62",
    issuedBy: COMPANY,
    companyRegNo: REG_NO,
    supportPhone: SUPPORT_PHONE,
    supportEmail: SUPPORT_EMAIL
  });

  const outDir = path.join(process.cwd(), "issued-licences");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir);
  const safeName = schoolName.replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "") || "client";
  const outFile = path.join(outDir, `EXCEL-Smart-STG-Licence-${safeName}.json`);
  fs.writeFileSync(outFile, JSON.stringify(licence, null, 2));
  console.log("");
  console.log(`Licence created: ${outFile}`);
  console.log("Import this JSON file inside EXCEL Smart STG to activate the product.");
  rl.close();
})();
