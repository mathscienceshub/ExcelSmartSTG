@echo off
call "%~dp002_TEST_DESKTOP_APP.bat"
