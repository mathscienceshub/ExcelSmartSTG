EXCEL Smart STG Licence Tools - Build 62

Use CREATE_LICENCE.bat to create a school-specific licence JSON file.
The created file appears in the issued-licences folder.

Steps:
1. Double-click CREATE_LICENCE.bat.
2. Enter the school/client name.
3. Enter licence type: Demo, Trial, Annual or Lifetime.
4. Enter valid-from and valid-until dates.
5. Send the generated JSON file to the school.
6. In EXCEL Smart STG, use Import Licence File.

Do not edit generated licence files by hand. Editing them breaks the signature.
