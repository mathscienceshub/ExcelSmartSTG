EXCELlence Smart School Timetable Generator
EXCEL Smart STG
Version 1.0.0 (Build 72)

This is the full desktop package built around the working source-of-truth index.html supplied by the user.

Included:
- app/index.html
- main.js
- package.json
- installer build scripts
- dependency install script
- supporting project files and folders from the stable desktop shell

Official installer output name:
EXCEL-Smart-STG-Setup-1.0.0-Build72.exe

Recommended build steps:
1. Extract this ZIP fully.
2. Move the extracted folder to a simple path, for example:
   C:\EXCEL-Smart-STG
3. Run:
   BUILD_WINDOWS_INSTALLER.bat
4. Check the dist folder for:
   EXCEL-Smart-STG-Setup-1.0.0-Build72.exe

Build number remains Build 72.
