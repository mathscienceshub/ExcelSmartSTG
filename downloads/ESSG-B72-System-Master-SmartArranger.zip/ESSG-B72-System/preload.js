const { contextBridge } = require("electron");

contextBridge.exposeInMainWorld("excellenceDesktop", {
  platform: process.platform,
  desktopBuild: true,
  product: "EXCEL Smart STG",
  version: "1.0.0",
  build: "62"
});
