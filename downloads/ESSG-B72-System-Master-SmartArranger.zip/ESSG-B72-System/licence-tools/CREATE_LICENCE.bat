@echo off
cd /d "%~dp0"
node create-licence.js
pause
