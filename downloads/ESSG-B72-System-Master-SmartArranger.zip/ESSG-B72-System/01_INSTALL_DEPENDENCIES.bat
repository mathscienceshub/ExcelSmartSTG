@echo off
title EXCEL Smart STG - Install Dependencies
cd /d "%~dp0"

if not exist build-logs mkdir build-logs

echo ================================================
echo  EXCEL Smart STG - Install Dependencies
echo ================================================
echo.
echo Installing dependencies. Internet is required the first time.
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not added to PATH.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: npm is not installed or not added to PATH.
  pause
  exit /b 1
)

call npm install --no-audit --no-fund > build-logs\npm-install.log 2>&1
if errorlevel 1 (
  echo.
  echo ERROR: npm install failed.
  echo Open build-logs\npm-install.log to see the exact reason.
  pause
  exit /b 1
)

echo.
echo Dependencies installed.
pause
