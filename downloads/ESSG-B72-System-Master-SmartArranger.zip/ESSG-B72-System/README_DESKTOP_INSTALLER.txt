EXCELlence Smart School Timetable Generator (EXCEL Smart STG)
Desktop Installer Pack
Version 1.0.0 (Build 72)

Produced under:
Maths n Sciences Hub (Pty) Ltd
Company Registration Number: 2026/337825/07

Support:
+27 76 106 9888 / +27 78 204 3618
chrisabel3414@gmail.com


WHAT THIS PACKAGE IS
====================
This package prepares EXCEL Smart STG as a Windows desktop application using Electron.

It contains:
- The stable EXCEL Smart STG web app from Build 72.
- Desktop wrapper files.
- Windows installer build script.
- Portable app build script.
- App icon placeholder.
- Desktop About menu and print support.


IMPORTANT
=========
This ZIP is an installer-ready source package.

The actual .exe installer must be built on your Windows laptop because Electron and electron-builder need to download desktop build dependencies through npm.


REQUIREMENTS ON YOUR LAPTOP
===========================
1. Windows laptop/computer.
2. Node.js LTS installed.
   Recommended: download Node.js LTS from the official Node.js website.
3. Internet connection for the first build only, because npm must install Electron dependencies.


RECOMMENDED BUILD ORDER
=======================
1. Extract the ZIP.
2. Move the folder to C:\EXCEL-Smart-STG.
3. Run 00_CHECK_REQUIREMENTS.bat.
4. Run 01_INSTALL_DEPENDENCIES.bat.
5. Run 02_TEST_DESKTOP_APP.bat.
6. Run 03_BUILD_INSTALLER_AND_PORTABLE.bat.


HOW TO TEST THE DESKTOP APP BEFORE BUILDING
===========================================
1. Extract this ZIP.
2. Open the extracted folder.
3. Double-click:

   INSTALL_AND_RUN_DEV.bat

4. Wait for npm install to finish.
5. The desktop app should open.


HOW TO BUILD THE WINDOWS INSTALLER
==================================
1. Extract this ZIP.
2. Open the extracted folder.
3. Double-click:

   BUILD_WINDOWS_INSTALLER.bat

4. Wait for the process to finish.
5. Open the new "dist" folder.

Expected output:
- EXCEL-Smart-STG-Setup-1.0.0.exe
- EXCEL-Smart-STG-Portable-1.0.0.exe


HOW TO BUILD PORTABLE VERSION ONLY
==================================
1. Double-click:

   BUILD_PORTABLE_ONLY.bat

2. Output will appear inside the "dist" folder.


WHERE DATA IS SAVED
===================
The desktop app uses local app storage.

To find the app data folder:
1. Open the desktop app.
2. Go to File.
3. Click "Open App Data Folder".

Important:
Always use Backup JSON inside EXCEL Smart STG before:
- major timetable changes,
- regeneration,
- moving to another computer,
- uninstalling or reinstalling the app.


RECOMMENDED FIRST RELEASE APPROACH
==================================
For demos:
- Use the Portable .exe or Developer Run.

For school installation:
- Use the Setup .exe installer.

For safety:
- Keep a copy of the Backup JSON separately on a flash drive, OneDrive, Google Drive, or external hard drive.


CURRENT PRODUCT IDENTITY
========================
Product name:
EXCELlence Smart School Timetable Generator

Short name:
EXCEL Smart STG

Product version:
Version 1.0.0 (Build 72)

Produced under:
Maths n Sciences Hub (Pty) Ltd

Company Reg. No:
2026/337825/07


FIXED BUILD PACK NOTE
=====================
This fixed pack adds:
- Step-by-step numbered BAT files.
- Build logs inside the build-logs folder.
- Separate installer-only and portable-only build options.
- Unpacked app test packaging if installer fails.
- Stronger troubleshooting guide.

Use 03_BUILD_INSTALLER_AND_PORTABLE.bat to create the .exe files.


BUILD 72 LICENCE GATE HOTFIX
============================
This hotfix fixes the issue where the licensed Build 72 app contained licence code but did not show/enforce the licence prompt.

Fixes:
- renderAll() now calls renderLicenceGate().
- The app shows the licence activation screen when no valid licence exists.
- Generate/export/restore actions are guarded by active licence checks.
- Product-facing version inside the app is now Version 1.0.0 (Build 72).

Recommended test:
1. Build installer from this pack.
2. Install/open the app.
3. It should show "EXCEL Smart STG Licence Required".
4. Import a valid licence JSON.
5. The Dashboard should show the licence as active.
