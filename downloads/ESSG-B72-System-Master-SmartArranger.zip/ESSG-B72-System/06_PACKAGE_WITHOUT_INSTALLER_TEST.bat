@echo off
title EXCEL Smart STG - Test Package Without Installer
cd /d "%~dp0"

if not exist build-logs mkdir build-logs

if not exist node_modules (
  call 01_INSTALL_DEPENDENCIES.bat
)

echo This creates an unpacked desktop app folder in dist without creating an installer.
echo It is useful when installer build fails but the app itself is okay.
echo.

call npm run dist:dir > build-logs\dir-package.log 2>&1

if errorlevel 1 (
  echo ERROR: Directory package failed. Check build-logs\dir-package.log
  pause
  exit /b 1
)

dir dist
pause
