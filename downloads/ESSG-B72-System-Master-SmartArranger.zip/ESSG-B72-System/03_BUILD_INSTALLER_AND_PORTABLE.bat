@echo off
title EXCEL Smart STG - Build Installer and Portable
cd /d "%~dp0"

if not exist build-logs mkdir build-logs

echo ================================================
echo  EXCEL Smart STG - Build Installer and Portable
echo ================================================
echo.
echo The installer is the official rollout file.
echo Portable is optional. If portable fails, the installer may still be usable.
echo.

call 04_BUILD_INSTALLER_ONLY.bat
if errorlevel 1 (
  echo.
  echo ERROR: Installer failed, so portable build will not continue.
  pause
  exit /b 1
)

echo.
echo Building optional portable EXE...
call npm run dist:portable > build-logs\portable-only.log 2>&1

if errorlevel 1 (
  echo.
  echo WARNING: Portable build failed, but the installer build already completed.
  echo Open build-logs\portable-only.log if you want to inspect the portable issue.
  echo.
  echo For school rollout, use the installer in the dist folder.
  dir dist
  pause
  exit /b 0
)

echo.
echo Installer and portable build finished.
dir dist
pause
