const { app, BrowserWindow, Menu, shell, dialog } = require("electron");
const path = require("path");

const PRODUCT_NAME = "EXCEL Smart STG";
const SHORT_NAME = "EXCEL Smart STG";
const VERSION = "1.0.0";
const BUILD = "72";
const PRODUCER = "Maths n Sciences Hub (Pty) Ltd";
const RIGHTS = "All rights reserved."; 
const SUPPORT_PHONE = "+27 76 106 9888 / +27 78 204 3618";
const SUPPORT_EMAIL = "chrisabel3414@gmail.com";

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1350,
    height: 900,
    minWidth: 1100,
    minHeight: 720,
    title: `${SHORT_NAME} v${VERSION} Build ${BUILD}`,
    icon: path.join(__dirname, "assets", "icon.ico"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, "app", "index.html"));

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

function showAbout() {
  dialog.showMessageBox(mainWindow, {
    type: "info",
    title: `About ${SHORT_NAME}`,
    message: PRODUCT_NAME,
    detail: [
      `${SHORT_NAME}`,
      `Version ${VERSION} (Build ${BUILD})`,
      `Produced under: ${PRODUCER}`,
      `© 2026 ${PRODUCER}. ${RIGHTS}`,
      "",
      `Support: ${SUPPORT_PHONE}`,
      `Email: ${SUPPORT_EMAIL}`,
      "",
      "Important: Use Backup JSON inside the app before major timetable changes or regeneration."
    ].join("\n"),
    buttons: ["OK"]
  });
}

function createMenu() {
  const template = [
    {
      label: "File",
      submenu: [
        {
          label: "Print / Save as PDF",
          accelerator: "Ctrl+P",
          click: () => mainWindow && mainWindow.webContents.print()
        },
        {
          label: "Open App Data Folder",
          click: () => shell.openPath(app.getPath("userData"))
        },
        { type: "separator" },
        {
          label: "Exit",
          accelerator: "Alt+F4",
          click: () => app.quit()
        }
      ]
    },
    {
      label: "View",
      submenu: [
        { role: "reload", label: "Reload App" },
        { role: "togglefullscreen", label: "Toggle Full Screen" },
        { type: "separator" },
        { role: "zoomIn", label: "Zoom In" },
        { role: "zoomOut", label: "Zoom Out" },
        { role: "resetZoom", label: "Reset Zoom" }
      ]
    },
    {
      label: "Help",
      submenu: [
        { label: "About", click: showAbout },
        {
          label: "Contact Support",
          click: () => {
            shell.openExternal(`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(SHORT_NAME + " Support")}`);
          }
        }
      ]
    }
  ];

  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  createWindow();
  createMenu();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
